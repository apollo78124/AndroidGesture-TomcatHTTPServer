Eunhak Lee Imageview App. 
A01026056

- Please populate the external storage of the phone at this directory: phone\Android\data\com.<example>.<applicationName>\files\Pictures
If you don't have any images, use the images inside the SampleImages folder in this application package. 

- For part B, touch gestures need to be applied to either left or right edge of the image. 

Part A - Completed
Part B - Completed
Part C - Completed
Part D - Completed
Part E - Completed
