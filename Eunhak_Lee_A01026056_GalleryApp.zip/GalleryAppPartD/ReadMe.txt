Eunhak Lee Imageview App. 

- Please populate the external storage of the phone at this directory: phone\Android\data\com.<example>.<applicationName>\files\Pictures
If you don't have any images, use the images inside the SampleImages folder in this application package. 