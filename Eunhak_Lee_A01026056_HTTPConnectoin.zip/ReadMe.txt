Eunhak Lee Imageview App. 
A01026056

- Please populate the external storage of the phone at this directory: phone\Android\data\com.<example>.<applicationName>\files\Pictures

- In case of the emulator, in most cases,directory is storage\emulated\0\Android\data\com.example.galleryappeunhaklee\files\Pictures
If you don't have any images, use the images inside the SampleImages folder in this application package. 

- This application only works on ".jpg" files. 

- Please copy the "midp" folder in this package and put it in your tomcat server directory: %tomcat%/webapps/

- When the images are uploaded on the tomcat server, it gets saved in the %tomcat%/bin/WebContents/images/ directory. If this directory doesn't exist in your tomcat installation, it will be created when the first image is uploaded. 

- When testing part B, please populate the %tomcat%/bin/WebContents/images/ directory with the 8b52.jpg file given in the SampleImages folder in this package. 

- For Part C, each save takes about 15 seconds. Give it a time until you save the next picture. 

Part A - Completed
Part B - Completed
Part C - Completed

